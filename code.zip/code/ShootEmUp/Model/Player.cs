﻿using ShootEmUp.Properties;

namespace ShootEmUp
{
    // Cette partie de la classe Player définit ce qu'est un modèle numérique du joueur
    public class Player
    {
        public const int FRAMEINVINCIBLE = 20;
        public const int COOLDOWN = 20; 
        public int vieplayer;                           // Un nom
        public int x;                                 // Position en X depuis la gauche de l'espace aérien
        public int y;                               // Position en Y depuis le haut de l'espace aérien
        public int timenomove = COOLDOWN;
        public int timeinvincible = FRAMEINVINCIBLE;
        public int score = 0;

        // Constructeur
        public Player(int x, int y)
        {
            this.x = x;
            this.y = y;
            this.vieplayer = 3;
        }

        // Cette méthode calcule le nouvel état dans lequel le joueur se trouve après
        // que 'interval' millisecondes se sont écoulées
        public void Update(int interval)
        {
            timenomove--;
            timeinvincible--;
            if (timenomove <= 0)
                shoot();
        }

        // Déplacement
        public void ChangeDirection(bool side)
        {
            int space = GameSpace.WIDTH - Config.PLAYER_SIZE;
            x += side ? 10 : -10;
            x = (x + space) % space;
            timenomove = COOLDOWN;
        }

        private Pen playerBrush = new Pen(new SolidBrush(Color.Purple), 3);

        // De manière graphique
        public void Render(BufferedGraphics drawingSpace)
        {
            drawingSpace.Graphics.DrawImage(Resources.player, x - Config.PLAYER_SIZE/2, y - Config.PLAYER_SIZE / 2, Config.PLAYER_SIZE, Config.PLAYER_SIZE);
            if(vieplayer == 3)
                drawingSpace.Graphics.DrawImage(Resources._3vies, x - Config.PLAYER_LIFE_SIZE / 2, y - (Config.PLAYER_LIFE_SIZE / 6), Config.PLAYER_LIFE_SIZE, Config.PLAYER_LIFE_SIZE);
            if (vieplayer == 2)
                drawingSpace.Graphics.DrawImage(Resources._2vies, x - Config.PLAYER_LIFE_SIZE / 2, y - (Config.PLAYER_LIFE_SIZE / 6), Config.PLAYER_LIFE_SIZE, Config.PLAYER_LIFE_SIZE);
            if (vieplayer == 1)
                drawingSpace.Graphics.DrawImage(Resources._1vie, x - Config.PLAYER_LIFE_SIZE / 2, y - (Config.PLAYER_LIFE_SIZE / 6), Config.PLAYER_LIFE_SIZE, Config.PLAYER_LIFE_SIZE);
            
        }

        public Tir shoot()
        {
            Tir tir = new Tir(x, y - Config.PLAYER_SIZE / 2, Tir.Type.PLAYER);
            return tir;
            
        }
    }
}
